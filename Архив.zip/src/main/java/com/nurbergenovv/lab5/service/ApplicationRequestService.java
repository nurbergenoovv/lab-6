package com.nurbergenovv.lab5.service;

import org.springframework.stereotype.Service;

public interface ApplicationRequestService {

}
