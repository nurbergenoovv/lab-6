package com.nurbergenovv.lab5.service;


import com.nurbergenovv.lab5.repository.OperatorRepository;
import org.springframework.stereotype.Service;

public interface OperatorService {
}
