package com.nurbergenovv.lab5.entity;


import jakarta.persistence.*;
import lombok.Data;

import java.util.List;

@Data
@Entity()
@Table(name = "operators")
public class Operator {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String name;
    private String surname;
    private String department;
    @ManyToMany(fetch = FetchType.EAGER)
    List<ApplicationRequest> requests;


}
